from atexit import register
from django.contrib import admin

from APP.models import Diak

admin.site.register(Diak)

# Register your models here.
